#!/usr/bin/env python3
"""
Debug script to test SerpAPI with the public HTTP server
"""

import requests
import json

def test_serpapi_with_public_url():
    """Test SerpAPI with the publicly accessible image"""
    
    # Configuration
    serpapi_key = "ffdc1a91340395fc2b40cc14735e27e5d226474da8c1f7f50c00d181522b377d"
    public_ip = "31.97.227.80"
    http_port = 2001
    image_filename = "hujra-restaurant-ring.jpg"  # Latest uploaded image
    
    # Construct the public URL
    image_url = f"http://{public_ip}:{http_port}/{image_filename}"
    
    print("="*80)
    print("SerpAPI Debug Test")
    print("="*80)
    print(f"\n1. Testing image accessibility:")
    print(f"   Image URL: {image_url}")
    
    # Test if image is accessible
    try:
        test_resp = requests.head(image_url, timeout=5)
        print(f"   Status: {test_resp.status_code}")
        print(f"   Content-Type: {test_resp.headers.get('Content-Type', 'Unknown')}")
        print(f"   Content-Length: {test_resp.headers.get('Content-Length', 'Unknown')} bytes")
        if test_resp.status_code == 200:
            print("   ✅ Image is publicly accessible!")
        else:
            print("   ❌ Image is not accessible!")
            return
    except Exception as e:
        print(f"   ❌ Error accessing image: {e}")
        return
    
    print(f"\n2. Testing SerpAPI:")
    print(f"   API Key: {serpapi_key[:10]}...")
    
    # Make SerpAPI request
    params = {
        'engine': 'google_reverse_image',
        'image_url': image_url,
        'api_key': serpapi_key
    }
    
    try:
        print(f"   Making request to SerpAPI...")
        resp = requests.get('https://serpapi.com/search', params=params, timeout=30)
        print(f"   Response Status: {resp.status_code}")
        
        if resp.status_code != 200:
            print(f"   ❌ SerpAPI request failed!")
            print(f"   Response: {resp.text}")
            return
        
        data = resp.json()
        
        print(f"\n3. SerpAPI Response:")
        print(f"   Response Keys: {list(data.keys())}")
        
        # Pretty print the full response
        print(f"\n4. Full Response (formatted):")
        print(json.dumps(data, indent=2))
        
        # Check for specific fields
        print(f"\n5. Analysis:")
        
        if 'error' in data:
            print(f"   ❌ Error: {data['error']}")
        
        if 'search_information' in data:
            search_info = data['search_information']
            print(f"   Search Info: {search_info}")
            if 'organic_results_state' in search_info:
                print(f"   Organic Results State: {search_info['organic_results_state']}")
        
        if 'image_results' in data:
            print(f"   ✅ Found {len(data['image_results'])} image results")
            for i, img in enumerate(data['image_results'][:3]):
                print(f"      Image {i+1}:")
                print(f"         Title: {img.get('title', 'N/A')}")
                print(f"         Source: {img.get('source', 'N/A')}")
                print(f"         Link: {img.get('link', 'N/A')}")
        else:
            print(f"   ℹ️ No image_results in response")
        
        if 'knowledge_graph' in data:
            print(f"   ✅ Knowledge Graph found")
            kg = data['knowledge_graph']
            for k, v in list(kg.items())[:5]:
                print(f"      {k}: {v}")
        else:
            print(f"   ℹ️ No knowledge_graph in response")
        
        if 'organic_results' in data:
            print(f"   ✅ Found {len(data['organic_results'])} organic results")
            for i, res in enumerate(data['organic_results'][:3]):
                print(f"      Result {i+1}:")
                print(f"         Title: {res.get('title', 'N/A')}")
                print(f"         Link: {res.get('link', 'N/A')}")
                if 'snippet' in res:
                    print(f"         Snippet: {res['snippet'][:100]}...")
        else:
            print(f"   ℹ️ No organic_results in response")
        
        if 'best_guess' in data:
            print(f"   ✅ Best Guess: {data['best_guess']}")
        else:
            print(f"   ℹ️ No best_guess in response")
        
        print("\n" + "="*80)
        print("Test Complete!")
        print("="*80)
        
    except Exception as e:
        print(f"   ❌ Exception occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_serpapi_with_public_url()

