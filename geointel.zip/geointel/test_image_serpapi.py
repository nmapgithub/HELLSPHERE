#!/usr/bin/env python3
"""
Test SerpAPI with specific image
"""

import requests
import json

def test_image():
    serpapi_key = "ffdc1a91340395fc2b40cc14735e27e5d226474da8c1f7f50c00d181522b377d"
    public_ip = "31.97.227.80"
    http_port = 2001
    image_filename = "583053335.jpg"
    
    # Test both localhost and public IP
    urls = [
        f"http://localhost:{http_port}/{image_filename}",
        f"http://{public_ip}:{http_port}/{image_filename}"
    ]
    
    for image_url in urls:
        print("="*80)
        print(f"Testing: {image_url}")
        print("="*80)
        
        # First check if image is accessible
        try:
            test_resp = requests.head(image_url, timeout=5)
            print(f"Image accessibility: {test_resp.status_code}")
            if test_resp.status_code == 200:
                print(f"✅ Image is accessible")
                print(f"Content-Type: {test_resp.headers.get('Content-Type')}")
                print(f"Content-Length: {test_resp.headers.get('Content-Length')} bytes")
            else:
                print(f"❌ Image not accessible")
                continue
        except Exception as e:
            print(f"❌ Error accessing image: {e}")
            continue
        
        # Now test SerpAPI
        params = {
            'engine': 'google_reverse_image',
            'image_url': image_url,
            'api_key': serpapi_key
        }
        
        try:
            print(f"\nMaking SerpAPI request...")
            resp = requests.get('https://serpapi.com/search', params=params, timeout=30)
            print(f"Response Status: {resp.status_code}")
            
            if resp.status_code == 200:
                data = resp.json()
                print(f"\nResponse Keys: {list(data.keys())}")
                
                if 'error' in data:
                    print(f"❌ Error: {data['error']}")
                
                if 'search_information' in data:
                    si = data['search_information']
                    print(f"\nSearch Information:")
                    for key, value in si.items():
                        print(f"  {key}: {value}")
                
                if 'image_results' in data:
                    print(f"\n✅ Found {len(data['image_results'])} image results")
                    for i, img in enumerate(data['image_results'][:3], 1):
                        print(f"\n  Result {i}:")
                        print(f"    Title: {img.get('title', 'N/A')}")
                        print(f"    Source: {img.get('source', 'N/A')}")
                        print(f"    Link: {img.get('link', 'N/A')}")
                else:
                    print(f"\nℹ️ No image_results found")
                
                # Print full response
                print(f"\n{'-'*80}")
                print("Full Response:")
                print(json.dumps(data, indent=2))
                
            else:
                print(f"❌ API request failed: {resp.text}")
                
        except Exception as e:
            print(f"❌ Exception: {e}")
        
        print("\n")

if __name__ == "__main__":
    test_image()

